// LN Solutions - servidor sin dependencias (solo Node 18+)
const tls=require('tls'),http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=process.env.PORT||3000;
const ADMIN_PATH=('/'+(process.env.ADMIN_PATH||'ln-admin')).replace(/\/+/g,'/').replace(/\/$/,'');
const USER=process.env.ADMIN_USER||'LN',PASS=process.env.ADMIN_PASS||'LN#2027..5820';
const FILE=path.join(process.env.DATA_DIR||__dirname,'data.json');
const ST={orders:['Solicitado','Atendido','Enviado','Entregado'],tickets:['Solicitado','Atendido','En revisión','Reparado','Entregado']};
const DEVS=['Computadora','Celular','Tablet','Impresora','Vehículo'];
let db={products:[
 {id:'p1',tipo:'Producto',nombre:'Laptop 15" reacondicionada',precio:15500,desc:'Core i5, 16 GB RAM, SSD 512 GB. Garantía de 6 meses.'},
 {id:'p2',tipo:'Producto',nombre:'Impresora multifunción WiFi',precio:3600,desc:'Imprime, copia y escanea desde el celular.'},
 {id:'p3',tipo:'Producto',nombre:'Cargador universal para laptop',precio:700,desc:'Ocho puntas intercambiables, protección contra sobrecarga.'},
 {id:'s1',tipo:'Servicio',nombre:'Mantenimiento preventivo de computadora',precio:900,desc:'Limpieza interna, pasta térmica y revisión de software.'},
 {id:'s2',tipo:'Servicio',nombre:'Instalación de red WiFi',precio:1500,desc:'Configuración de router y cobertura en todo el espacio.'}],orders:[],tickets:[]};
try{db=Object.assign(db,JSON.parse(fs.readFileSync(FILE,'utf8')))}catch(e){}
const save=()=>{const t=FILE+'.tmp';fs.writeFileSync(t,JSON.stringify(db,null,1));fs.renameSync(t,FILE)};
const tokens=new Map(),tries=new Map();
const h=s=>crypto.createHash('sha256').update(String(s)).digest();
const same=(a,b)=>crypto.timingSafeEqual(h(a),h(b));
const S=(v,n=200)=>String(v==null?'':v).trim().slice(0,n);
const mail=v=>/^\S+@\S+\.\S+$/.test(v);
const newId=p=>p+'-'+crypto.randomBytes(3).toString('hex').toUpperCase();
const send=(res,code,obj)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(obj))};
const body=req=>new Promise((ok,no)=>{let d='';req.on('data',c=>{d+=c;if(d.length>1e5){no(new Error('big'));req.destroy()}});req.on('end',()=>{try{ok(JSON.parse(d||'{}'))}catch(e){no(e)}})});
const SITE=process.env.SITE_NAME||'LN Solutions';
const L=n=>'L '+Number(n).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
const b64=s=>Buffer.from(String(s),'utf8').toString('base64');
// Envío por SMTP con TLS directo (puerto 465). Sin dependencias.
function sendMail(to,subject,text){
 return new Promise((ok,no)=>{
  const H=process.env.SMTP_HOST,U=process.env.SMTP_USER,P=process.env.SMTP_PASS;
  if(!H||!U||!P)return ok(false);
  const from=process.env.MAIL_FROM||U,addr=a=>(a.match(/<([^>]+)>/)||[0,a])[1];
  const msg=['From: '+from,'To: '+to,'Subject: =?UTF-8?B?'+b64(subject)+'?=','MIME-Version: 1.0','Content-Type: text/plain; charset=UTF-8','Content-Transfer-Encoding: base64','',b64(text).match(/.{1,76}/g).join('\r\n')].join('\r\n');
  const q=['EHLO ln-solutions','AUTH LOGIN',b64(U),b64(P),'MAIL FROM:<'+addr(from)+'>','RCPT TO:<'+addr(to)+'>','DATA',msg+'\r\n.','QUIT'];
  let step=0,buf='',end=false;
  const sock=tls.connect({host:H,port:+(process.env.SMTP_PORT||465),servername:H});
  const fin=(e)=>{if(end)return;end=true;sock.destroy();e?no(e):ok(true)};
  sock.setTimeout(15000,()=>fin(new Error('tiempo agotado')));
  sock.on('error',fin);
  sock.on('data',d=>{buf+=d.toString();const last=buf.trimEnd().split(/\r?\n/).pop();if(!/^\d{3} /.test(last))return;buf='';
   if(+last.slice(0,3)>=400)return fin(new Error(last));
   if(step>=q.length)return fin();
   sock.write(q[step++]+'\r\n');});
 });
}
const mailQ=(to,s,t)=>{if(to)sendMail(to,s,t).catch(e=>console.log('Correo no enviado:',e.message))};
function notifyNew(col,r){
 const o=col==='orders',tipo=o?'compra':'solicitud de soporte';
 const det=o?r.items.map(i=>'- '+i.qty+' x '+i.nombre+' ('+L(i.precio*i.qty)+')').join('\n')+'\nTotal: '+L(r.total):'Dispositivo: '+r.dispositivo+' '+r.marca+' '+r.modelo+'\nProblema: '+r.problema;
 mailQ(r.correo,SITE+': recibimos tu '+tipo+' '+r.id,'Hola '+r.nombre+',\n\nRecibimos tu '+tipo+'. Tu número de seguimiento es '+r.id+'.\n\n'+det+'\n\nNos pondremos en contacto contigo al '+r.telefono+'.\n\n'+SITE);
 mailQ(process.env.NOTIFY_TO,'Nueva '+tipo+' '+r.id,'Cliente: '+r.nombre+'\nTeléfono: '+r.telefono+'\nCorreo: '+r.correo+'\n'+(o?'Ciudad: '+r.ciudad+'\n':'')+'\n'+det);
}
function notifyStatus(r){mailQ(r.correo,SITE+': tu solicitud '+r.id+' cambió de estatus','Hola '+r.nombre+',\n\nEl estatus de tu solicitud '+r.id+' ahora es: '+r.estatus+'.\n\n'+SITE)}
const authed=req=>{const t=(req.headers.authorization||'').slice(7);const x=tokens.get(t);return x&&x>Date.now()};

http.createServer(async(req,res)=>{
 const u=new URL(req.url,'http://x'),p=u.pathname,m=req.method;
 try{
  if(m==='GET'&&(p===ADMIN_PATH||p===ADMIN_PATH+'/')){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Robots-Tag':'noindex'});return res.end(fs.readFileSync(path.join(__dirname,'public','admin.html')))}
  if(m==='GET'&&(p==='/'||p==='/index.html')){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});return res.end(fs.readFileSync(path.join(__dirname,'public','index.html')))}
  if(!p.startsWith('/api/'))return send(res,404,{error:'no encontrado'});
  if(m==='GET'&&p==='/api/products')return send(res,200,db.products);
  if(m==='GET'&&p.startsWith('/api/track/')){const id=decodeURIComponent(p.slice(11)).toUpperCase();const r=db.orders.concat(db.tickets).find(x=>x.id===id);return r?send(res,200,{id:r.id,estatus:r.estatus,fecha:r.fecha}):send(res,404,{error:'no encontrado'})}
  if(m==='POST'&&p==='/api/orders'){
   const b=await body(req),f={nombre:S(b.nombre,100),ciudad:S(b.ciudad,100),telefono:S(b.telefono,30),correo:S(b.correo,120)};
   const items=(Array.isArray(b.items)?b.items:[]).slice(0,50).map(i=>{const pr=db.products.find(x=>x.id===i.id),q=Math.min(99,Math.max(1,parseInt(i.qty)||1));return pr?{id:pr.id,nombre:pr.nombre,precio:pr.precio,qty:q}:null}).filter(Boolean);
   if(!f.nombre||!f.ciudad||!f.telefono||!mail(f.correo)||!items.length)return send(res,400,{error:'datos incompletos'});
   const rec=Object.assign({id:newId('LN-C'),fecha:new Date().toISOString(),estatus:'Solicitado',items,total:items.reduce((a,x)=>a+x.precio*x.qty,0)},f);
   db.orders.push(rec);save();notifyNew('orders',rec);return send(res,201,{id:rec.id});
  }
  if(m==='POST'&&p==='/api/tickets'){
   const b=await body(req),r={nombre:S(b.nombre,100),telefono:S(b.telefono,30),correo:S(b.correo,120),dispositivo:S(b.dispositivo,30),marca:S(b.marca,60),modelo:S(b.modelo,60),problema:S(b.problema,1500)};
   if(!r.nombre||!r.telefono||!mail(r.correo)||!DEVS.includes(r.dispositivo)||!r.marca||!r.modelo||!r.problema)return send(res,400,{error:'datos incompletos'});
   const rec=Object.assign({id:newId('LN-S'),fecha:new Date().toISOString(),estatus:'Solicitado'},r);
   db.tickets.push(rec);save();notifyNew('tickets',rec);return send(res,201,{id:rec.id});
  }
  if(m==='POST'&&p==='/api/login'){
   const ip=req.socket.remoteAddress,t=tries.get(ip)||{n:0,until:0};
   if(t.until>Date.now())return send(res,429,{error:'demasiados intentos'});
   const b=await body(req);
   if(same(b.usuario,USER)&&same(b.clave,PASS)){tries.delete(ip);const tk=crypto.randomBytes(24).toString('hex');tokens.set(tk,Date.now()+8*36e5);return send(res,200,{token:tk})}
   t.n++;if(t.n>=5){t.n=0;t.until=Date.now()+15*6e4}tries.set(ip,t);return send(res,401,{error:'credenciales incorrectas'});
  }
  if(p.startsWith('/api/admin/')){
   if(!authed(req))return send(res,401,{error:'no autorizado'});
   const seg=p.split('/').slice(3);
   if(m==='GET'&&seg[0]==='data')return send(res,200,{orders:db.orders,tickets:db.tickets});
   if(m==='PUT'&&ST[seg[0]]){const r=db[seg[0]].find(x=>x.id===seg[1]),b=await body(req);if(!r||!ST[seg[0]].includes(b.estatus))return send(res,400,{error:'inválido'});r.estatus=b.estatus;save();notifyStatus(r);return send(res,200,{ok:1})}
   if(m==='POST'&&seg[0]==='products'){
    const b=await body(req),rec={id:S(b.id,40)||newId('p').toLowerCase(),nombre:S(b.nombre,120),tipo:b.tipo==='Servicio'?'Servicio':'Producto',precio:Math.max(0,Number(b.precio)||0),desc:S(b.desc,300)};
    if(!rec.nombre)return send(res,400,{error:'nombre requerido'});
    const i=db.products.findIndex(x=>x.id===rec.id);if(i<0)db.products.push(rec);else db.products[i]=rec;save();return send(res,200,rec);
   }
   if(m==='DELETE'&&seg[0]==='products'){db.products=db.products.filter(x=>x.id!==seg[1]);save();return send(res,200,{ok:1})}
  }
  send(res,404,{error:'no encontrado'});
 }catch(e){send(res,400,{error:'solicitud inválida'})}
}).listen(PORT,()=>console.log('Tienda: http://localhost:'+PORT+'  |  Administración: http://localhost:'+PORT+ADMIN_PATH));
