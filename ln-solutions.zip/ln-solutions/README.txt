LN SOLUTIONS - Puesta en marcha
1) node server.js   (requiere Node 18+, sin instalar paquetes)
2) Tienda:          http://TU-DOMINIO/
   Administración:  http://TU-DOMINIO/ln-admin   (no aparece en la tienda)

Variables de entorno (configúralas en tu hosting):
  ADMIN_USER, ADMIN_PASS   Usuario y contraseña del panel (cámbialas)
  ADMIN_PATH               Ruta del panel, por defecto ln-admin
  DATA_DIR                 Carpeta donde se guarda data.json (usa disco persistente)
  PORT                     Puerto (por defecto 3000)
Correos (SMTP con TLS, puerto 465; con Gmail usa una "contraseña de aplicación"):
  SMTP_HOST   p. ej. smtp.gmail.com
  SMTP_PORT   465
  SMTP_USER   tu correo
  SMTP_PASS   contraseña o contraseña de aplicación
  MAIL_FROM   remitente, p. ej. LN Solutions <tucorreo@gmail.com>
  NOTIFY_TO   correo donde recibirás avisos de cada compra/solicitud
Si no configuras SMTP, el sitio funciona igual pero no envía correos.
